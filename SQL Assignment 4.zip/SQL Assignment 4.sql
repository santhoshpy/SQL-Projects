use Assignment
--Qn 1

select min(amount) as minamount,
       max(amount) as maxamount,
	   avg (amount) as avgamount
	   from orders
--Qn2
 create function multiply(@num  as int)
returns int
as
begin
return
(@num * 10)
end
select dbo.multiply(10) as result

--Qn3
select * from Customer

select
case
when (100 < 200) then '100 is less than 200'
when (100 = 200) then '100 is equal to 200'
when (100 >200) then '100 is greater than 200'
end
