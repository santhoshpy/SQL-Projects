
Create database NewAssignment

use NewAssignment

create table studies
(Pname varchar(50) primary key,
institute varchar(50),
course varchar(50),
course_fee int
)

insert into Studies values

('Anand','Sabhari','PGDCA',4500),
('Altaf','Coit','DCA',7200),
('Juliana','BDPS','MCA',22000),
('Kamala','Pragathi','DCA',5000),
('Mary','Sabhari','PGDCA',4500),
('Nelson','Pragathi','DAP',6200),
('Pattrick','Pragathi','DCAP',5200),
('Qudir','Apple','HDCA',14000),
('Ramesh','Sabhari','PGDCA',4500),
('Rebecca','Brilliant','DCAP',11000),
('Remitha','BDPS','DCS',6000),
('Revathi','Sabhari','DAP',5000),
('Vijaya','BDPS','DCA',48000)

Create table Software
(
PName varchar(50) foreign key references studies(Pname),
Title varchar(50),
DevelopIn Varchar(20),
Scost float,
Dcost float,
Sold int
)



insert into Software values

('Mary','ReadMe','CCP',300,1200,84),
('Anand','Parachutes','Basic',399.95,6000,43),
('Anand','Video Titling','Pascal',7500,16000,9),
('Juliana','Inventory','COBOL',3000,3500,0),
('Kamala','Payroll Pkg','DBASE',9000,20000,7),
('Mary','Financial Acct','Oracle',18000,85000,4),
('Mary','Code Generator','C',4500,20000,23),
('Pattrick','ReadMe','CCP',300,1200,84),
('Qudir','Bombs','Assembly',750,3000,11),
('Qudir','Vaccines','C',1900,3100,21),
('Ramesh','Hotal Mgmt','DBASE',13000,35000,4),
('Ramesh','Dead Lee','Pascal',599.95,4500,73),
('Remitha','PC Utilities','C',725,5000,51),
('Remitha','TSR Help Pkg','Assembly',2500,6000,7),
('Revathi','Hospital Mgmt','Pascal',1100,75000,2),
('Vijaya','TSR Editor','C',900,700,6)


create table Programmer
(
PName varchar(50)foreign key references studies(PName),
DOB date,
DOJ date,
Gender varchar(10),
Prof1 varchar(10),
Prof2 varchar(10),
Salary int
)

insert into Programmer values

('Anand','12-Apr-66','21-Apr-92','M','Pascal','Basic',3200),
('Altaf','02-Jul-64','13-Nov-90','M','Clipper','Cobol',2800),
('Juliana','31-Jan-60','21-Apr-90','F','Cobol','DBASE',3000),
('Kamala','30-Oct-68','02-Jan-92','F','C','DBASE',2900),
('Mary','24-Jun-70','01-Feb-91','F','DPP','Oracle',4500),
('Nelson','11-Sep-85','11-Oct-89','M','Cobol','DBASE',2500),
('Pattrick','10-Nov-65','21-Apr-90','M','Pascal','Clipper',2800),
('Qudir','31-Aug-65','21-Apr-91','M','Assembly','C',3000),
('Ramesh','03-May-67','28-Feb-91','M','Pascal','DBASE',3200),
('Rebecca','01-Jan-67','01-Dec-90','F','Basic','Cobol',2500),
('Remitha','19-Apr-70','20-Apr-93','F','C','Assembly',3600),
('Revathi','02-Dec-69','02-Jan-92','F','Pascal','Basic',3700),
('Vijaya','14-Dec-65','02-May-92','F','Foxpro','C',3500)

select * from Studies
select * from Software
select * from Programmer




---Qn1
select Avg(Scost) as Average_cost from software
where DevelopIn = 'pascal'

--Qn2
select Pname , dob, getdate() as currentdate,DATEDIFF(yy,DOB,getdate()) AS age from programmer
where gender = 'f'
--Qn3
select pname from studies
where course like 'dap'
--Qn4-- need to work
Select pname ,dob from Programmer
where month(dob) like 01

--Qn5
Select max(sold ) as package from software

--Qn6
select min(course_fee)as lowestfee from studies
--Qn7
select count(Pname) as count from studies
where course like 'pgdca'
--Qn8
select sum(scost*Sold) as revenue from software
where DevelopIn like 'c'
--Qn9
select developin from software
where pname like 'ramesh'
--Qn10
Select count (pname) from studies
where institute = 'sabhari'
--Qn11
select * from software
where (scost*sold) > 2000
--Qn12

select * from software
where (scost*sold >= dcost)

--QN 13
select max(dcost) from software

--Qn 14
--How many Packages Developed in DBASE?
select count(developin) as number from software
where developin like 'dbase'

--Qn15

--How many programmers studied in Pragathi?

select count(institute) as no_of_prog from studies
where institute like 'pragathi'

--Qn16
--How many Programmers Paid 5000 to 10000 for their course?
select * from studies
where course_fee between 5000 and 10000

--Qn17
--What is AVG Course Fee
select AVG(course_fee)as AVG_FEE from studies

--Qn18
	--Display the details of the Programmers Knowing C.
	select * from programmer
	where( prof1  = 'c'or prof2 = 'C')

--Qn19
select * from programmer
where prof1  = 'cobol'or prof1 = 'pascal' or prof2  = 'cobol'or prof2 = 'pascal'

--Qn20
---How many Programmers Don�t know PASCAL and C

select * from programmer
 where prof1  != 'pascal' and prof1 != 'c' and prof2  != 'C'and prof2 != 'pascal'

 --Qn21
 --How old is the Oldest Male Programmer
select max(
case
when dateadd(year, datediff(YYYY,dob,getdate()), dob)>getdate()
then DATEDIFF (yy,DOB,getdate()) -1
else
DATEDIFF(year,dob,getdate()) end) as age
from programmer
where gender = 'M'
--Qn 22

select avg(
case
when dateadd(year, datediff(YYYY,dob,getdate()), dob)>getdate()
then DATEDIFF (yy,DOB,getdate()) -1
else
DATEDIFF(year,dob,getdate()) end) as Avgage
from programmer
where gender like'F'
--Qn23
select pname,(
case
when dateadd(year, datediff(YYYY,doJ,getdate()), doJ)>getdate()
then DATEDIFF (yy,DOJ,getdate()) -1
else
DATEDIFF(year,doJ,getdate()) end) as Experience
from programmer
order by experience desc


--Qn 24

select Pname,(
case
when dateadd(year, datediff(YYYY,dob,getdate()), dob)>getdate()
then DATEDIFF (yy,DOB,getdate()) -1
else
DATEDIFF(year,dob,getdate()) end) as Avgage
from programmer
where month(dob) = 12


--Qn 25

select count(PName) from programmer
where gender = 'F'

--Qn 26
Select prof1, prof2 from Programmer
where gender like 'M'
--Qn 27
select avg (salary) from Programmer
--Qn 28

select PName, Salary from Programmer where salary between 2000 and  4000
--Qn 29

select * from programmer
 where prof1 != 'clipper' and prof1 != 'cobol' and Prof1  != 'Pascal'and
  prof2 != 'clipper' and prof2 != 'cobol' and Prof2  != 'Pascal'

--Qn30

select pname, dcost from Software
--Qn31
select pname, (scost*Sold) as salesvalue from Software
--Qn 32
Select pname, sum(sold) from Software
group by PName
--Qn 33
select PName,sum(scost*Sold)as salesvalue,developin as languagewise from Software
group by PName ,DevelopIn
--Qn 34
select developin as languages,avg(dcost)as avg_development_cost, avg (scost)as avg_Selling_cost, avg(scost*sold) as avg_cost_per_person from software
group by DevelopIn
--Qn 35
select  pname max(dcost)as Costliest, min(dcost) as  cheapest from software
group by PName
--Qn 36
select institute , count(course) , avg (course_fee)
from studies
group by institute
--Qn 37
select institute ,count(pname)as students from studies
group by institute
--Qn 38
select pname, gender from Programmer
group by gender,pname
--Qn 39
select pname,salary from Programmer
--Qn 40
select developin as languages , count(title)  from Software
group by DevelopIn
having DevelopIn != 'c' and DevelopIn != 'c++'
--Qn 41
select developin as languages ,count(developin)as Numberofpackages from software
where Dcost <1000
group by developin
--Qn42
select Title as package, Avg(Scost -Dcost) as AVGDIFF  from Software
group by Title
--Qn 43
select pname ,sum(scost)as SCost,sum(dcost) as Dcost, sum(Dcost - (scost*sold)) as recovered from software
group by PName 
having sum(scost*sold) < sum(dcost)

--Qn 44
select max(salary)as HIGHEST , min(salary) AS lOWEST ,Avg(Salary) AS AVERAGE from Programmer
WHERE Salary >2000

--qN 45
Select *  from Programmer
where salary =(select max(salary)from Programmer where Prof1 = 'c'or Prof2 = 'c')
--Qn 46
Select *  from Programmer
where salary =(select max(salary) from Programmer where Prof1 = 'cobol'or Prof2 = 'cobol')
and gender ='f'
--Qn 47


WITH CTC AS (
  SELECT PNAME, SALARY, PROF1 AS PROF FROM programmer
  UNION 
  SELECT PNAME, SALARY, PROF2 FROM programmer
)
SELECT p1.PNAME, p1.PROF, p1.SALARY
FROM CTC as p1
LEFT JOIN CTC as 
p2
  ON p1.PROF = p2.PROF AND p1.SALARY < p2.SALARY
WHERE p2.PNAME IS NULL;

--Qn 48
select min(
case
when dateadd(year, datediff(YYYY,doJ,getdate()), doJ)>getdate()
then DATEDIFF (yy,DOJ,getdate()) -1
else
DATEDIFF(year,doJ,getdate()) end) as Experience
from programmer

--Qn 49

select max(
case
when dateadd(year, datediff(YYYY,doJ,getdate()), doJ)>getdate()
then DATEDIFF (yy,DOJ,getdate()) -1
else
DATEDIFF(year,doJ,getdate()) end) as Experience
from programmer
where Prof1 ='pascal' or Prof2 ='pascal'

--Qn 50

SELECT PROF1 FROM PROGRAMMER
GROUP BY PROF1
HAVING PROF1 NOT IN
(SELECT PROF2 FROM PROGRAMMER)
AND COUNT(PROF1)=1
UNION
SELECT PROF2 FROM PROGRAMMER
GROUP BY PROF2
HAVING PROF2 NOT IN
(SELECT PROF1 FROM PROGRAMMER)
AND COUNT(PROF2)=1;
--Qn51
create table pslanguage (prof varchar (20))
select * from pslanguage

insert into pslanguage
SELECT PROF1 FROM PROGRAMMER
GROUP BY PROF1
HAVING PROF1 NOT IN
(SELECT PROF2 FROM PROGRAMMER)
AND COUNT(PROF1)=1
UNION
SELECT PROF2 FROM PROGRAMMER
GROUP BY PROF2
HAVING PROF2 NOT IN
(SELECT PROF1 FROM PROGRAMMER)
AND COUNT(PROF2)=1;

select PName,prof from pslanguage inner join Programmer
on prof1 = prof or prof = Prof2

--Qn 52
select Pname,(
case
when dateadd(year, datediff(YYYY,dob,getdate()), dob)>getdate()
then DATEDIFF (yy,DOB,getdate()) -1
else
DATEDIFF(year,dob,getdate()) end) as age
from programmer
where dob =( select max(dob) from Programmer where Prof1 = 'DBASE' or prof2 = 'DBASE')

--Qn 53
select * from Programmer
where salary > 3000 and Gender = 'f' and Prof1 != 'c'AND prof1 != 'c++' AND prof1 != 'oracle' AND prof1 != 'DBASE' AND
Prof2 != 'c'AND prof2 != 'c++' AND prof2 != 'oracle' AND prof2 != 'DBASE'

--Qn54
CREATE TABLE InStudentNo (InstituteName VARCHAR(20), StdNo INT)

INSERT INTO InStudentNo
SELECT INSTITUTE,COUNT(PNAME) FROM studies GROUP BY INSTITUTE

SELECT InstituteName,StdNo AS COUNT_OF_STUDENTS FROM InStudentNo
WHERE StdNo = (SELECT MAX(StdNo) FROM InStudentNo)

select * from InStudentNo
--Qn 55
select course from studies
where course_fee =(
select max(course_fee)  from studies) 
--QN56
create table coursecount (course varchar(50), studncount int)
insert into coursecount
select course, count(pname) from studies
group by course
select* from coursecount

select course , studncount from coursecount
where studncount = (select max(studncount) from coursecount) 

--Qn57
select institute from studies
where course_fee = (select max(course_fee) from studies)
--Qn 58
--Display the name of the Institute and Course, which has below AVG course fee
select institute ,course from studies
 where course_fee < (select  avg(course_fee) from studies)
 --Qn 59
 --Display the names of the courses whose fees are within 1000 (+ or -) of the Average Fee
 select course from studies
 where course_fee < (select  avg(course_fee)+1000 from studies) and course_fee >(select avg(course_fee)-1000 from studies) 

 --Qn60
 --Which package has the Highest Development cost?
 select title, Dcost from Software where Dcost = (select max(dcost) from Software)
 --QN61
--Which course has below AVG number of Students?

--Qn62
select title, Scost from Software where Scost = (select min(Scost) from Software)
--Qn 63
select PName, Sold from Software where Sold = (select min(Sold) from Software)
--Qn 64
select title,Scost, developin from Software where scost = (select max(scost) from software)
--Qn65
select sold,Title  from Software where (dcost- scost)=(select min(dcost- scost) from software)
--Qn66
Select Title,Dcost from software where dcost =(select max(Dcost) from software where  DevelopIn like 'pascal')
 --Qn 67
 Select developin,Title ,sold from Software
 group by DevelopIn,Title, Sold
 having DevelopIn= (select max(DevelopIn) from Software)

 --Qn68
  Select PName from Software group by Pname having PName= (select max(PName) from Software)
 --Qn 69
 select pname,Dcost from Software  where dcost =(Select max(Dcost) from software)
 --Qn70
 select title, developin from software where sold <(select avg(sold) from software)
 --Qn 71
select distinct pname from software where Dcost	< (2*(sold*scost))
--Qn 72
Select PName,Title from Software where Dcost in (select min(Dcost) from Software group by DevelopIn)
--Qn 73
select pname  ,DevelopIn, Sold from software
where sold in
(select max (Sold) from Software)
union
select pname  ,DevelopIn, Sold from software
where sold in
(select min (Sold) from Software)
--Qn 74
select pname,
case
when dateadd(year, datediff(year, dob,getdate()), dob) > getdate()
then datediff( year, dob, getdate()) -1
else
datediff (year, dob, getdate()) end as age
from Programmer
where dob = (select max(dob) from Programmer where year (dob) like 1965 and gender = 'M')

--Qn75

select pname,
case
when dateadd(year, datediff(year, dob,getdate()), dob) > getdate()
then datediff( year, dob, getdate()) -1
else
datediff (year, dob, getdate()) end as age
from Programmer
where dob = (select min(dob) from Programmer where year(DOJ) like 1992 and gender = 'F')

--QN76
CREATE TABLE born (Yearborn INT, Countin INT)

INSERT INTO born
SELECT YEAR(DOB) AS YEAR ,COUNT(pname) FROM programmer GROUP BY YEAR(DOB)
select * from born

Select yearborn, Countin from born
where Countin = (select max(countin) from born)

---Qn77
CREATE TABLE joinin
(Yearjoin INT, Countin INT)
INSERT INTO joinin
SELECT YEAR(DOJ) AS YEAR ,COUNT(pname) FROM programmer GROUP BY YEAR(DOJ)
select * from joinin

Select yearjoin, Countin from joinin
where Countin = (select max(countin) from joinin)
--Qn78


CREATE TABLE lanpro
( profic varchar (20), cnt int)
INSERT INTO lanpro

select distinct prof1 ,count(pname) from Programmer group by Prof1
union
select distinct Prof2 ,count(pname) from Programmer group by Prof2

select * from lanpro

CREATE TABLE lanp
( profic varchar (20), cnt int)
INSERT INTO lanp
select profic, sum(cnt) from lanpro group by profic

select profic,cnt from lanp
where cnt = (select max(cnt) from lanp)
--Qn79
--Who are the male programmers earning below the AVG salary of Female Programmers?
select pname ,salary from Programmer where Gender = 'm'and
Salary< (select avg (Salary) from Programmer where Gender = 'f') 

--QN 80
--Who are the Female Programmers earning more than the Highest Paid?
select pname ,salary from Programmer where Gender = 'F'and
Salary> (select max (Salary) from Programmer where Gender = 'M' ) 
--Qn 81
--Which language has been stated as the proficiency by most of the Programmers?
select max(prof1) as proficiency from Programmer 
union
select max(prof2) from Programmer 
--Qn 82
select * from Programmer where Salary in (select Salary from Programmer group by Salary having count(salary) >1) 

--Qn83
--Display the details of the Software Developed by the Male Programmers Earning More than 3000/-.
select * from software inner join Programmer
on Software.PName = Programmer.PName
where salary > 3000 and gender = 'm'

--Qn 84
--Display the details of the packages developed in Pascal by the Female Programmers
select * from software inner join Programmer on Software.PName = Programmer.PName
where DevelopIn = 'pascal' and Gender = 'f'
--QN85
--Display the details of the Programmers who joined before 1990.
Select * from Programmer where year (DOJ) <1990
--Qn 86
--Display the details of the Software Developed in C By female programmers of Pragathi.
select Software.* from studies inner join Software  on studies.PName = Software.PName inner join Programmer on software.pname = Programmer.pname
where Gender = 'f' and institute = 'pragathi'
--QN87
--Display the number of packages, No. of Copies Sold and sales value of each programmer institute wise.
select  studies.institute ,count(software.DevelopIn) as developin, count(software.Sold)  as softwaresales, sum(software.sold*software.Scost) as sales from Software,studies  
where software.pname = studies.Pname group by institute
--Qn88
--Display the details of the software developed in DBASE by Male Programmers, who belong to the institute in which most number of Programmers studied.


select software.*, studies.institute from software  inner join studies  on studies.PName = Software.PName inner join Programmer on software.pname = Programmer.pname
where DevelopIn = 'dbase' and gender = 'm'

--Qn 89
select Software.*, YEAR(dob),Gender  from  Software inner join Programmer
 on software.pname = Programmer.pname where (( Gender = 'M' and year(dob) < 1965)  or( Gender = 'F' and YEAR(dob) >1975))

 --Qn90
 select *, DevelopIn  from  Software inner join Programmer
 on software.pname = Programmer.pname where  prof1 <> Developin  and prof2 <>developIN 
 --Qn 91
 
select Software.* from studies inner join Software  on studies.PName = Software.PName inner join Programmer on software.pname = Programmer.pname
where Gender = 'M' and institute = 'Sabhari'
--Qn92
select pname  from  Programmer   where  pname not in (select pname from Software)
--Qn93
select sum(Dcost) from studies inner join software  on studies.PName = Software.PName inner join Programmer on software.pname = Programmer.pname
where institute = 'apple'
--QN 94
Select a.doj , a.pname from Programmer a, Programmer b
where a.doj = b.DOJ and a.pname <> b.PName

SELECT doj,PName FROM Programmer a
WHERE doj IN (SELECT doj FROM Programmer b  WHERE a.pname <> b.PName);
--Qn 95 
 SELECT distinct PName, Prof2 FROM Programmer a
WHERE Prof2 IN (SELECT Prof2 FROM Programmer b  WHERE a.pname <> b.PName);

--Qn96

select institute, sum(scost*Sold)as SALESVALUE from studies inner join software  on studies.PName = Software.PName inner join Programmer on software.pname = Programmer.pname
group by institute
--QN 97

select institute,Dcost  from studies inner join software  on studies.PName = Software.PName 
where dcost = (select max(dcost) from Software)

--Qn98

 select prof1 from Programmer where Prof1 not in (select developin from Software)
 union
  select Prof2 from Programmer where Prof2 not in (select developin from Software) 
 --Qn99
select Salary,course  from studies inner join software  on studies.PName = Software.PName inner join Programmer on software.pname = Programmer.pname
where Scost =(select max(Scost) from Software)

--Qn 100
select avg(salary) as avgsalary from Software inner join Programmer on software.pname = Programmer.pname
where (Scost*sold )> 50000
--Qn101
select software.Pname, count(title) as numberofpackages  from studies inner join software on software.pname = studies.pname
group by software.Pname,course_fee
having min(course_fee) =(select min(course_fee) from studies)
 
--Qn 102
select count(developin) as packages, studies.institute from studies inner join software on software.pname = studies.pname
group by studies.institute
having min(dcost) = (select min(dcost) from Software)

--Qn 103
select count(developin) as packages from Programmer inner join software on software.pname = Programmer.pname
where gender = 'f' 
and  (salary) > (select max(salary) from programmer where gender = 'm') 

--Qn 104
select count(*) from software s,programmer p
where p.pname=s.pname group by doj having min(doj)=(select min(doj)
from studies st,programmer p, software s
where p.pname=s.pname and st.pname=p.pname and (institute='BDPS'));

--Qn 105
select pname, institute from studies
where pname not in (select pname from software)
--Qn 106
--List each PROF with the number of Programmers having that PROF and the number of the packages in that PROF.
select prof1,count(software.PName) as Numberofprogrammers from Programmer inner join software on software.pname = Programmer.pname
where prof1 = DevelopIn
group by Prof1
union
select Prof2,count(software.PName) as Numberofprogrammers from Programmer inner join software on software.pname = Programmer.pname
where Prof2 = DevelopIn
group by Prof2

--QN107 List the programmer names (from the programmer table) and No. Of Packages each has developed.
select software.PName ,count (software.DevelopIn) as numberofpackages from  Programmer inner join software on software.pname = Programmer.pname
group by software.PName

