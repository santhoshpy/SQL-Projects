Use Assignment
Create table Employee_Table

(
Emplyoee_id int  primary key not null, First_name varchar(50), Last_Name varchar(50),
Salary int, Joining_date datetime, Department varchar(50)
)

insert into Employee_Table values
 (1, 'Ankita', 'Arora', 100000, '2020-02-14 9:00:00', 'HR'),
 (2, 'Veena', 'Verma', 80000, '2011-06-15 9:00:00', 'Admin'),
(3, 'Vishal', 'Singhal', 300000, '2020-02-16 09:00:00', 'HR'),
(4, 'Sushanth', 'Singh', 500000, '2020-02-17 09:00:00', 'Admin'),
(5, 'Bhupal', 'Bhati', 500000, '2011-06-18 09:00:00', 'Admin'),
(6, 'Dhooraj', 'Diwan', 200000, '2011-06-19 09:00:00', 'Account'),
(7, 'Karan', 'kumar', 75000, '2020-01-14 09:00:00', 'Account'),
(8, 'Chandrika', 'Chauhan', 90000, '2011-04-15 09:00:00', 'Admin')



Create table Employee_Bonus_Table 
(Emplyoee_ref_id int not null,
 Bonus_Amount int , Bonus_Date varchar(50),
 foreign key(Emplyoee_ref_id) references Employee_Table(Emplyoee_id)	
 on delete cascade
 ) 
 drop table Employee_Bonus_Table

insert into Employee_Bonus_Table values
(1, 5000 , '2020-02-16 0:00:00'),
(2, 3000 , '2011-06-16 0:00:00'),
(3, 4000, '2020-02-16 0:00:00'),
(1, 4500, '2020-02-16 0:00:00'),
(2, 3500, '2020-02-16 0:00:00')


create table Employee_Title_Table
(Employee_ref_id int , Emplyoee_title varchar(50), Affective_date datetime)


insert into Employee_Title_Table values
(1, 'Manager', '2016-02-20 0:00:00'),
(2, 'Executive', '2016-06-11 0:00:00'),
(8, 'Executive', '2016-06-11 0:00:00'),
(5, 'Manager', '2016-06-11 0:00:00'),
(4, 'Asst.Manager', '2016-06-11 0:00:00'),
(7, 'Executive', '2016-06-11 0:00:00'),
(6, 'Lead', '2016-06-11 0:00:00'),
(3, 'Lead', '2016-06-11 0:00:00')

select * from Employee_Title_Table
select * from Employee_Table
select * from Employee_Bonus_Table

--Qn1

SELECT FIRST_NAME as[Employee_name] FROM EMPLOYEE_TABLE 
--Qn2

SELECT Upper(Last_name) FROM employee_table

--Qn3
select distinct department from employee_table
--Qn4
select substring(Last_name, 1,3) from Employee_table
--Qn5
select distinct len (department) from employee_table
--Qn6
 select *,CONCAT (First_Name, ' ',  last_name) as Full_Name
 from employee_table

--Qn7
select* from employee_table
order by First_name asc
--Qn8

select *from Employee_Table 
order by First_name asc,
         department desc

--Qn9
select* from Employee_Table
where first_name in( 'veena', 'karan') 

--Qn10

select* from Employee_Table
where Department = 'Admin'
--Qn11
select* from Employee_Table
where first_name like 'v%'
--Qn12
select* from Employee_Table
where Salary between 100000 and 500000

--Qn13


      
select* from Employee_Table
where year(joining_date) like '2020%' and
     month(joining_date) like '2%'
	 
--Qn14


 select *,CONCAT (First_Name, ' ',  last_name) as Employee_Name
 from employee_table
 where Salary in 
(select salary from Employee_Table where Salary between 50000 and 100000)

--15 Display the no. of employees for each department in the descending order.

select Department, count(Emplyoee_id) as Employee_count
	from Employee_Table
group by Department

--Qn16

select* from Employee_Table inner join Employee_Title_Table
on employee_table.Emplyoee_id = employee_title_table.Employee_ref_id
where Emplyoee_title = 'Manager'

--Qn 17
select Emplyoee_ref_id, count(Emplyoee_ref_id) as duplicateids
from Employee_Bonus_Table
group by emplyoee_ref_id
having count (emplyoee_ref_id) >1
--Qn18

select * from Employee_Table 
where Emplyoee_id %2 = 1
--Qn19


select * into clone from Employee_Table 
select * from clone 

--Qn20
select distinct top 2 salary from Employee_Table
 
order by salary desc

--Qn21
       
select distinct E.Emplyoee_id, E.First_Name, E.Salary from Employee_table E, Employee_Table E1 
where E.Salary = E1.Salary and E.Emplyoee_ID != E1.Emplyoee_id


--Qn22
select MAX (Salary) from employee_table
where Salary < (select MAX (Salary) from employee_table)


--Qn 23
select top 50 percent * from Employee_Table

--Qn24
select Department, count(Emplyoee_id) as 'No of Emplyoee'
from Employee_Table
group by Department 
having count(Emplyoee_id) <4
--Qn 25
select Department, count(Emplyoee_id) as 'No of Emplyoee'
from Employee_table
group by Department 

--Qn26


 select department, Salary, CONCAT (First_Name, ' ',  last_name) as Employee_Name
 from employee_table
 where salary in (
select max (salary) from Employee_Table  
group by  Department )
--Qn27

 select  CONCAT (First_Name, ' ',  last_name) as Employee_Name
 from employee_table
 where salary in (
select 	max (salary) from Employee_Table )

--Qn 28
select department , Avg(salary) as Average_salary from Employee_Table
group by Department

--Qn 29
select * from Employee_Table inner join Employee_Bonus_Table
 on Employee_Table.Emplyoee_id = Employee_Bonus_Table.Emplyoee_ref_id
 where bonus_amount in (select max (bonus_amount) from employee_bonus_table)

 


--Qn 30

select First_name,Emplyoee_title from Employee_Table inner join Employee_Title_Table
on Employee_table.Emplyoee_id = Employee_Title_Table.Employee_ref_id
