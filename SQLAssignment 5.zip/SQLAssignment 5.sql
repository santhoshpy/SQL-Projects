use Assignment
select * from Customer

--Qn1 
select * from orders
order by amount desc

--QN2

Create table Emplyoee_details1
(Emp_id int, Emp_name varchar(50) , Emp_salary int)

insert into Emplyoee_details1 values
(101,'Actors' , 1000000),
(121, 'Adithya' , 20000),
(122, 'vijay' , 30000),
(123, 'Suriya' , 40000),
(124, 'Vikaram' , 50000),
(125, 'Siva' , 60000)

create table Emplyoee_details2 
(Emp_id int , Emp_name varchar(50) , Emp_salary int)


insert into Emplyoee_details2 values
(101,'Actors' , 1000000),
(151, 'Asin' , 10000),
(152, 'Trisha' , 150000),
(153, 'Nayanthara' , 240000),
(154, 'Aiswarya' , 350000),
(155, 'Nithaya' , 620000)

--QN3
select * from Emplyoee_details1
union
select* from Emplyoee_details2

---QN4

select * from Emplyoee_details1
intersect
select* from Emplyoee_details2

--QN5
select * from Emplyoee_details1
except
select* from Emplyoee_details2

